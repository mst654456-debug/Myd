package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.fragment.app.FragmentActivity
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.navigation.Screen
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppDataViewModel
import com.example.ui.viewmodel.AuthViewModel

class MainActivity : FragmentActivity() {

    private val authViewModel: AuthViewModel by viewModels()
    private val dataViewModel: AppDataViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContent(authViewModel = authViewModel, dataViewModel = dataViewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(authViewModel: AuthViewModel, dataViewModel: AppDataViewModel) {
    val navController = rememberNavController()
    val authState by authViewModel.authState.collectAsState()
    val adminConfig by dataViewModel.adminConfig.collectAsState()
    val schools by dataViewModel.schools.collectAsState()
    val teachers by dataViewModel.teachers.collectAsState()
    val events by dataViewModel.events.collectAsState()
    val reportDraft by dataViewModel.reportDraft.collectAsState()

    NavHost(navController = navController, startDestination = Screen.Splash.route) {

        // Splash (كما هي)
        composable(Screen.Splash.route) {
            SplashScreen(
                isAuthenticated = authState.isAuthenticated,
                onNavigateNext = { isAuth ->
                    val target = when {
                        !adminConfig.isSetupCompleted -> Screen.FirstTimeSetup.route
                        isAuth -> Screen.Home.route
                        else -> Screen.Login.route
                    }
                    navController.navigate(target) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                }
            )
        }

        // الإعداد الأولي لأول مرة (كما هو)
        composable(Screen.FirstTimeSetup.route) {
            FirstTimeSetupScreen(
                initialDirectorate = adminConfig.directorateName,
                initialAdministration = adminConfig.administrationName,
                initialDirectorGeneral = adminConfig.directorGeneralName,
                initialSecurityOfficer = adminConfig.securityOfficerName,
                onSaveAndContinue = { dir, adm, dg, sec ->
                    dataViewModel.saveAdminConfig(dir, adm, dg, sec)
                    val target = if (authState.isAuthenticated) Screen.Home.route else Screen.Login.route
                    navController.navigate(target) {
                        popUpTo(Screen.FirstTimeSetup.route) { inclusive = true }
                    }
                }
            )
        }

        // الدخول بالبصمة (كما هو)
        composable(Screen.Login.route) {
            LoginScreen(onAuthenticated = { authViewModel.loginWithBiometric() })
            LaunchedEffect(authState.isAuthenticated) {
                if (authState.isAuthenticated) {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                }
            }
        }

        composable(Screen.Home.route) {
            HomeScreen(
                adminConfig = adminConfig,
                schoolsCount = schools.size,
                teachersCount = teachers.size,
                eventsCount = events.size,
                onSchools = { navController.navigate(Screen.Schools.route) },
                onTeachers = { navController.navigate(Screen.Teachers.route) },
                onEvents = { navController.navigate(Screen.Events.route) },
                onReport = { navController.navigate(Screen.ReportText.route) },
                onImport = { navController.navigate(Screen.Import.route) },
                onSettings = { navController.navigate(Screen.Settings.route) }
            )
        }

        composable(Screen.Import.route) {
            ImportScreen(
                onImportSchools = { uri, done -> dataViewModel.importSchools(uri, done) },
                onImportTeachers = { uri, done -> dataViewModel.importTeachers(uri, done) },
                onBack = { navController.popBackStack() }
            )
        }

        // ---------- المدارس ----------
        composable(Screen.Schools.route) {
            SchoolsScreen(
                schools = schools,
                onAdd = { navController.navigate(Screen.SchoolForm.createRoute()) },
                onOpen = { school -> navController.navigate(Screen.SchoolDetail.createRoute(school.id)) },
                onDelete = { dataViewModel.deleteSchool(it) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.SchoolDetail.route,
            arguments = listOf(navArgument("schoolId") {
                type = NavType.LongType
                defaultValue = -1L
            })
        ) { entry ->
            val schoolId = entry.arguments?.getLong("schoolId") ?: -1L
            SchoolDetailScreen(
                school = schools.firstOrNull { it.id == schoolId },
                teachers = teachers.filter { it.schoolId == schoolId },
                events = events.filter { it.schoolId == schoolId },
                onEdit = { school -> navController.navigate(Screen.SchoolForm.createRoute(school.id)) },
                onDelete = { school ->
                    dataViewModel.deleteSchool(school)
                    navController.popBackStack()
                },
                onAddTeacher = { school -> navController.navigate(Screen.TeacherForm.createRoute(schoolId = school.id)) },
                onEditTeacher = { teacher -> navController.navigate(Screen.TeacherForm.createRoute(teacherId = teacher.id)) },
                onAddEvent = { school -> navController.navigate(Screen.EventForm.createRoute(schoolId = school.id)) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.SchoolForm.route,
            arguments = listOf(navArgument("schoolId") {
                type = NavType.LongType
                defaultValue = -1L
            })
        ) { entry ->
            val schoolId = entry.arguments?.getLong("schoolId") ?: -1L
            SchoolFormScreen(
                existing = schools.firstOrNull { it.id == schoolId },
                onSave = { id, values ->
                    dataViewModel.saveSchool(id, values) { navController.popBackStack() }
                },
                onBack = { navController.popBackStack() }
            )
        }

        // ---------- المعلمون ----------
        composable(Screen.Teachers.route) {
            TeachersScreen(
                teachers = teachers,
                schools = schools,
                onAdd = { navController.navigate(Screen.TeacherForm.createRoute()) },
                onOpen = { teacher -> navController.navigate(Screen.TeacherForm.createRoute(teacherId = teacher.id)) },
                onDelete = { dataViewModel.deleteTeacher(it) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.TeacherForm.route,
            arguments = listOf(
                navArgument("teacherId") {
                    type = NavType.LongType
                    defaultValue = -1L
                },
                navArgument("schoolId") {
                    type = NavType.LongType
                    defaultValue = -1L
                }
            )
        ) { entry ->
            val teacherId = entry.arguments?.getLong("teacherId") ?: -1L
            val presetSchoolId = entry.arguments?.getLong("schoolId") ?: -1L
            TeacherFormScreen(
                existing = teachers.firstOrNull { it.id == teacherId },
                presetSchoolId = if (presetSchoolId > 0) presetSchoolId else null,
                schools = schools,
                onSave = { id, schoolId, values ->
                    dataViewModel.saveTeacher(id, schoolId, values) { navController.popBackStack() }
                },
                onBack = { navController.popBackStack() }
            )
        }

        // ---------- الأحداث ----------
        composable(Screen.Events.route) {
            EventsScreen(
                events = events,
                onAdd = { navController.navigate(Screen.EventForm.createRoute()) },
                onOpen = { event -> navController.navigate(Screen.EventForm.createRoute(eventId = event.id)) },
                onDelete = { dataViewModel.deleteEvent(it) },
                onTransfer = { list ->
                    dataViewModel.prepareReportFromEvents(list)
                    navController.navigate(Screen.ReportText.route)
                },
                onPrint = { todayOnly ->
                    dataViewModel.prepareEventsReport(todayOnly)
                    navController.navigate(Screen.ReportText.route)
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.EventForm.route,
            arguments = listOf(
                navArgument("eventId") {
                    type = NavType.LongType
                    defaultValue = -1L
                },
                navArgument("schoolId") {
                    type = NavType.LongType
                    defaultValue = -1L
                }
            )
        ) { entry ->
            val eventId = entry.arguments?.getLong("eventId") ?: -1L
            val presetSchoolId = entry.arguments?.getLong("schoolId") ?: -1L
            EventFormScreen(
                existing = events.firstOrNull { it.id == eventId },
                presetSchoolId = if (presetSchoolId > 0) presetSchoolId else null,
                schools = schools,
                onSave = {
                    dataViewModel.saveEvent(it)
                    navController.popBackStack()
                },
                onBack = { navController.popBackStack() }
            )
        }

        // ---------- التقرير ----------
        composable(Screen.ReportText.route) {
            ReportTextScreen(
                draft = reportDraft,
                adminConfig = adminConfig,
                onDraftChange = { dataViewModel.setReportDraft(it) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                adminConfig = adminConfig,
                onSave = { d, a, dg, s -> dataViewModel.saveAdminConfig(d, a, dg, s) },
                onLogout = {
                    authViewModel.logout()
                    navController.navigate(Screen.Login.route) {
                        popUpTo(navController.graph.id) { inclusive = true }
                    }
                },
                onBack = { navController.popBackStack() }
            )
        }
    }
}
