package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.preferences.AdminConfig
import com.example.ui.components.AppTopBar
import com.example.util.PdfReportBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReportTextScreen(
    draft: String,
    adminConfig: AdminConfig,
    onDraftChange: (String) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    val canSend = draft.isNotBlank() && !busy
    val dateText = remember {
        SimpleDateFormat("dd / MM / yyyy", Locale("ar", "EG")).format(Date())
    }

    fun buildPdf(onReady: (File) -> Unit) {
        busy = true
        scope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    PdfReportBuilder.build(context, draft, adminConfig)
                }
                onReady(file)
            } catch (e: Exception) {
                Toast.makeText(context, "تعذر إنشاء ملف PDF: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                busy = false
            }
        }
    }

    Scaffold(topBar = { AppTopBar(title = "كتابة التقرير A4", onBack = onBack) }) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize()
                .verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "اكتب داخل الورقة البيضاء كما في Word. المعاينة بمقاس A4، وعند زيادة النص يكمل PDF تلقائياً في صفحات جديدة.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // A4 paper ratio: 210 × 297 mm. Preview mirrors the PDF header/body/footer.
            Surface(
                modifier = Modifier.fillMaxWidth().aspectRatio(210f / 297f)
                    .border(1.dp, Color(0xFFD5D9E0), RoundedCornerShape(2.dp)),
                color = Color.White, shadowElevation = 4.dp, shape = RoundedCornerShape(2.dp)
            ) {
                Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 18.dp)) {
                    Row(
                        Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Text("التاريخ: $dateText", color = Color(0xFF657080), fontSize = 8.sp)
                        Column(horizontalAlignment = Alignment.End) {
                            Text(adminConfig.directorateName, color = Color(0xFF14223A), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(adminConfig.administrationName, color = Color(0xFF14223A), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("مكتب الأمن", color = Color(0xFF14223A), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.fillMaxWidth().height(1.5.dp).background(Color(0xFF1565C0)))
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = draft, onValueChange = onDraftChange,
                        placeholder = { Text("اكتب نص التقرير هنا...", color = Color(0xFF9AA3AF), textAlign = TextAlign.Right, fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            color = Color(0xFF1E232D), fontSize = 12.sp,
                            textAlign = TextAlign.Start, lineHeight = 19.sp
                        ),
                        shape = RoundedCornerShape(2.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFD5DCE5)))
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(horizontalAlignment = Alignment.Start) {
                            Text("يعتمد / مدير عام الإدارة", color = Color(0xFF14223A), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            Text(adminConfig.directorGeneralName, color = Color(0xFF1565C0), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("إعداد / مسئول الأمن", color = Color(0xFF14223A), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            Text(adminConfig.securityOfficerName, color = Color(0xFF1565C0), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { buildPdf { file -> PdfReportBuilder.share(context, file) } },
                    enabled = canSend, shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
                    Text("إرسال PDF", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = { buildPdf { file -> PdfReportBuilder.print(context, file) } },
                    enabled = canSend, shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Icon(Icons.Filled.Print, contentDescription = null)
                    Text("طباعة", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
