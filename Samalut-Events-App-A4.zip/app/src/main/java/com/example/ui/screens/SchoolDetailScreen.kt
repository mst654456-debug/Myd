package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.FieldKind
import com.example.data.model.FormField
import com.example.data.model.School
import com.example.data.model.SchoolEvent
import com.example.data.model.SchoolSpec
import com.example.data.model.Teacher
import com.example.data.model.toValues
import com.example.ui.components.AppTopBar
import com.example.ui.components.ConfirmDialog
import com.example.ui.components.EmptyState
import com.example.ui.components.InfoLine
import com.example.ui.components.PhoneActions
import com.example.ui.components.SectionCard

@Composable
fun SchoolDetailScreen(
    school: School?,
    teachers: List<Teacher>,
    events: List<SchoolEvent>,
    onEdit: (School) -> Unit,
    onDelete: (School) -> Unit,
    onAddTeacher: (School) -> Unit,
    onEditTeacher: (Teacher) -> Unit,
    onAddEvent: (School) -> Unit,
    onBack: () -> Unit
) {
    var confirmDelete by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            AppTopBar(
                title = school?.name ?: "تفاصيل المدرسة",
                onBack = onBack,
                actions = {
                    if (school != null) {
                        IconButton(onClick = { onEdit(school) }) {
                            Icon(Icons.Filled.Edit, contentDescription = "تعديل")
                        }
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Filled.Delete, contentDescription = "حذف")
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (school == null) {
            Column(modifier = Modifier.padding(padding).fillMaxSize()) {
                EmptyState("المدرسة غير موجودة")
            }
        } else {
            val values = school.toValues()
            Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SectionCard("البيانات الأساسية") { DetailLines(SchoolSpec.basic, values) }
                SectionCard("القيادات والتواصل") { DetailLines(SchoolSpec.leadership, values) }
                SectionCard("الإحصاءات والقوى العاملة") { DetailLines(SchoolSpec.stats, values) }
                SectionCard("منظومة الأمن والسلامة") { DetailLines(SchoolSpec.safety, values) }
                SectionCard("الموقع والمشكلات") { DetailLines(SchoolSpec.location + SchoolSpec.problems, values) }

                SectionCard("المعلمون (${teachers.size})") {
                    if (teachers.isEmpty()) {
                        Text("لا يوجد معلمون مسجلون لهذه المدرسة")
                    }
                    teachers.forEach { teacher ->
                        TeacherRow(teacher = teacher, onClick = { onEditTeacher(teacher) })
                    }
                    OutlinedButton(onClick = { onAddTeacher(school) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إضافة معلم لهذه المدرسة")
                    }
                }

                SectionCard("الأحداث (${events.size})") {
                    if (events.isEmpty()) {
                        Text("لا توجد أحداث مسجلة لهذه المدرسة")
                    }
                    events.sortedByDescending { it.timestamp }.forEach { event ->
                        Column {
                            Text(event.title, fontWeight = FontWeight.SemiBold)
                            Text(
                                "${event.dateString} - ${event.timeString}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    Button(onClick = { onAddEvent(school) }, modifier = Modifier.fillMaxWidth()) {
                        Text("تسجيل حدث لهذه المدرسة")
                    }
                }
            }
        }
    }

    if (confirmDelete && school != null) {
        ConfirmDialog(
            title = "حذف المدرسة",
            message = "هيتم حذف «${school.name}» ومعلميها. الأحداث هتفضل في التقارير.",
            confirmText = "حذف",
            onConfirm = {
                confirmDelete = false
                onDelete(school)
            },
            onDismiss = { confirmDelete = false }
        )
    }
}

@Composable
private fun DetailLines(fields: List<FormField>, values: Map<String, String>) {
    fields.forEach { field ->
        val value = values[field.key].orEmpty()
        if (value.isNotBlank() && value != "0") {
            InfoLine(
                label = field.label,
                value = value,
                isPhone = field.kind == FieldKind.PHONE
            )
        }
    }
}

@Composable
private fun TeacherRow(teacher: Teacher, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(teacher.name, fontWeight = FontWeight.SemiBold)
            if (teacher.code.isNotBlank()) {
                Text("كود: ${teacher.code}", style = MaterialTheme.typography.bodySmall)
            }
        }
        PhoneActions(teacher.phone)
    }
}
