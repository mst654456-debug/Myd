package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.School
import com.example.data.model.Teacher
import com.example.ui.components.AppTopBar
import com.example.ui.components.ConfirmDialog
import com.example.ui.components.EmptyState
import com.example.ui.components.PhoneActions
import com.example.ui.components.SearchField
import com.example.ui.theme.EduBlue

@Composable
fun TeachersScreen(
    teachers: List<Teacher>,
    schools: List<School>,
    onAdd: () -> Unit,
    onOpen: (Teacher) -> Unit,
    onDelete: (Teacher) -> Unit,
    onBack: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<Teacher?>(null) }
    val schoolNames = remember(schools) { schools.associate { it.id to it.name } }
    val q = query.trim()
    val filtered = teachers.filter { t ->
        t.name.contains(q, ignoreCase = true) ||
            t.code.contains(q, ignoreCase = true) ||
            t.nationalId.contains(q) ||
            (schoolNames[t.schoolId] ?: "").contains(q, ignoreCase = true)
    }

    Scaffold(
        topBar = { AppTopBar(title = "المعلمون (${teachers.size})", onBack = onBack) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAdd,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("إضافة معلم") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            SearchField(value = query, onValueChange = { query = it }, placeholder = "بحث بالاسم أو المدرسة أو الرقم القومي")
            Spacer(modifier = Modifier.height(12.dp))

            if (filtered.isEmpty()) {
                EmptyState(
                    if (teachers.isEmpty()) "لا يوجد معلمون مسجلون بعد.\nاضغط «إضافة معلم» أو استورد من Excel."
                    else "لا توجد نتائج للبحث."
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filtered, key = { it.id }) { teacher ->
                        TeacherCard(
                            teacher = teacher,
                            schoolName = schoolNames[teacher.schoolId] ?: "مدرسة غير معروفة",
                            onClick = { onOpen(teacher) },
                            onDelete = { deleteTarget = teacher }
                        )
                    }
                }
            }
        }
    }

    deleteTarget?.let { target ->
        ConfirmDialog(
            title = "حذف المعلم",
            message = "هل تريد حذف المعلم «${target.name}»؟",
            confirmText = "حذف",
            onConfirm = {
                onDelete(target)
                deleteTarget = null
            },
            onDismiss = { deleteTarget = null }
        )
    }
}

@Composable
private fun TeacherCard(teacher: Teacher, schoolName: String, onClick: () -> Unit, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Person, contentDescription = null, tint = EduBlue, modifier = Modifier.size(36.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(teacher.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(schoolName, style = MaterialTheme.typography.bodySmall)
            }
            PhoneActions(teacher.phone)
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}
