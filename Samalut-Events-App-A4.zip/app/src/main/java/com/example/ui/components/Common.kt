package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.FieldKind
import com.example.data.model.FormField
import com.example.data.model.School
import com.example.ui.theme.EduBlue
import com.example.util.PhoneHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    TopAppBar(
        title = { Text(title, fontWeight = FontWeight.Bold) },
        navigationIcon = {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                }
            }
        },
        actions = actions,
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = EduBlue,
            titleContentColor = Color.White,
            navigationIconContentColor = Color.White,
            actionIconContentColor = Color.White
        )
    )
}

@Composable
fun SearchField(value: String, onValueChange: (String) -> Unit, placeholder: String) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        placeholder = { Text(placeholder) },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
fun EmptyState(text: String) {
    Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(
            text = text,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(confirmText, color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun SchoolPickerDialog(schools: List<School>, onPick: (School) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("اختر المدرسة", fontWeight = FontWeight.Bold) },
        text = {
            if (schools.isEmpty()) {
                Text("لا توجد مدارس مسجلة. أضف مدرسة أولاً.")
            } else {
                LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 380.dp)) {
                    items(schools, key = { it.id }) { school ->
                        TextButton(onClick = { onPick(school) }, modifier = Modifier.fillMaxWidth()) {
                            Text(school.name)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        }
    )
}

/** زرار اتصال وزرار واتساب بجانب أي رقم تليفون */
@Composable
fun PhoneActions(phone: String) {
    if (phone.isBlank()) return
    val context = LocalContext.current
    Row {
        IconButton(onClick = { PhoneHelper.call(context, phone) }) {
            Icon(Icons.Filled.Call, contentDescription = "اتصال", tint = EduBlue)
        }
        IconButton(onClick = { PhoneHelper.whatsapp(context, phone) }) {
            Icon(Icons.Filled.Chat, contentDescription = "واتساب", tint = Color(0xFF25D366))
        }
    }
}

private fun keyboardFor(kind: FieldKind): KeyboardType = when (kind) {
    FieldKind.NUMBER -> KeyboardType.Number
    FieldKind.DECIMAL -> KeyboardType.Decimal
    FieldKind.PHONE -> KeyboardType.Phone
    else -> KeyboardType.Text
}

/** حقول الفورم بالترتيب. القيم بتتخزن في map */
@Composable
fun FormFields(fields: List<FormField>, values: MutableMap<String, String>) {
    fields.forEach { field ->
        OutlinedTextField(
            value = values[field.key] ?: "",
            onValueChange = { values[field.key] = it },
            label = { Text(if (field.required) "${field.label} *" else field.label) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = field.kind != FieldKind.MULTILINE,
            minLines = if (field.kind == FieldKind.MULTILINE) 3 else 1,
            keyboardOptions = KeyboardOptions(keyboardType = keyboardFor(field.kind))
        )
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = EduBlue
    )
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = EduBlue)
            content()
        }
    }
}

/** سطر بيانات: العنوان فوق والقيمة تحته، ومعاه أزرار الاتصال لو الحقل تليفون */
@Composable
fun InfoLine(label: String, value: String, isPhone: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
        }
        if (isPhone) PhoneActions(value)
    }
}
