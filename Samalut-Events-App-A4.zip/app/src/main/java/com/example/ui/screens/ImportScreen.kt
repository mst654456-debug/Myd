package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.SchoolSpec
import com.example.data.model.TeacherSpec
import com.example.ui.components.AppTopBar
import com.example.ui.components.SectionCard
import com.example.util.ImportReport

private val FILE_TYPES = arrayOf(
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "text/csv",
    "text/comma-separated-values",
    "application/vnd.ms-excel"
)

@Composable
fun ImportScreen(
    onImportSchools: (Uri, (ImportReport) -> Unit) -> Unit,
    onImportTeachers: (Uri, (ImportReport) -> Unit) -> Unit,
    onBack: () -> Unit
) {
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<Pair<String, ImportReport>?>(null) }

    val pickSchools = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            onImportSchools(uri) { report ->
                busy = false
                result = "المدارس" to report
            }
        }
    }

    val pickTeachers = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            onImportTeachers(uri) { report ->
                busy = false
                result = "المعلمين" to report
            }
        }
    }

    Scaffold(topBar = { AppTopBar(title = "استيراد من Excel", onBack = onBack) }) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "ارفع ملف Excel (xlsx) أو CSV. أول صف في الملف لازم يكون أسماء الأعمدة، والبيانات تحته. " +
                    "لو المدرسة أو المعلم موجود قبل كده، التطبيق بيحدّث بياناته ولا بيكررهم.",
                style = MaterialTheme.typography.bodySmall
            )

            SectionCard("استيراد المدارس") {
                Text(
                    "الأعمدة: " + SchoolSpec.all.joinToString("، ") { it.label } + "، المرحلة",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(
                    onClick = { pickSchools.launch(FILE_TYPES) },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    Icon(Icons.Filled.Description, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("اختيار ملف المدارس", fontWeight = FontWeight.Bold)
                }
            }

            SectionCard("استيراد المعلمين") {
                Text(
                    "لازم يكون فيه عمود «اسم المعلم» وعمود «المدرسة» باسم المدرسة المسجلة بالظبط. " +
                        "الأعمدة الأخرى: " + TeacherSpec.fields.drop(1).joinToString("، ") { it.label },
                    style = MaterialTheme.typography.bodySmall
                )
                Button(
                    onClick = { pickTeachers.launch(FILE_TYPES) },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    Icon(Icons.Filled.Description, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("اختيار ملف المعلمين", fontWeight = FontWeight.Bold)
                }
            }

            if (busy) {
                CircularProgressIndicator(modifier = Modifier.padding(8.dp))
            }

            Text(
                text = "ملاحظة: لو الملف CSV وطلع فيه كلام مش مفهوم، احفظه من Excel باختيار «CSV UTF-8».",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    result?.let { (kind, report) ->
        AlertDialog(
            onDismissRequest = { result = null },
            title = { Text("نتيجة استيراد $kind", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("تمت إضافة ${report.added}، وتحديث ${report.updated}.")
                    if (report.skipped.isNotEmpty()) {
                        Text("تم تخطي ${report.skipped.size} صف:", fontWeight = FontWeight.Bold)
                        report.skipped.take(10).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                        if (report.skipped.size > 10) {
                            Text("... وغيرهم", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { result = null }) { Text("تم") }
            }
        )
    }
}
