package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.School
import com.example.data.model.SchoolEvent
import com.example.data.model.SchoolSpec
import com.example.data.model.SchoolStage
import com.example.data.model.Teacher
import com.example.data.model.TeacherSpec
import com.example.data.model.toSchool
import com.example.data.model.toTeacher
import com.example.data.model.toValues
import com.example.data.preferences.AdminConfig
import com.example.data.preferences.AdminPreferences
import com.example.util.ImportHelper
import com.example.util.ImportReport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AppDataViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val adminPrefs = AdminPreferences(application)

    val adminConfig: StateFlow<AdminConfig> = adminPrefs.adminConfig

    val schools: StateFlow<List<School>> = db.schoolDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val teachers: StateFlow<List<Teacher>> = db.teacherDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val events: StateFlow<List<SchoolEvent>> = db.eventDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // نص التقرير اللي بيتكتب في صفحة الإرسال ويتحول لـ PDF
    private val draftState = MutableStateFlow("")
    val reportDraft: StateFlow<String> = draftState.asStateFlow()

    fun setReportDraft(text: String) {
        draftState.value = text
    }

    fun saveAdminConfig(directorate: String, administration: String, directorGeneral: String, securityOfficer: String) {
        adminPrefs.saveConfig(directorate, administration, directorGeneral, securityOfficer)
    }

    /** ترحيل أحداث اليوم أو كل الأحداث للتقرير */
    fun prepareEventsReport(todayOnly: Boolean) {
        val todayStr = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date())
        val list = events.value.filter { !todayOnly || it.dateString == todayStr }
        val emptyText = if (todayOnly) "لا توجد أحداث بالإدارة لهذا اليوم" else "لا توجد أحداث مسجلة"
        draftState.value = buildReportText(list, emptyText)
    }

    /** ترحيل أحداث محددة للتقرير */
    fun prepareReportFromEvents(list: List<SchoolEvent>) {
        draftState.value = buildReportText(list, "لا توجد أحداث محددة")
    }

    /** التقرير مجمّع حسب المدرسة */
    private fun buildReportText(list: List<SchoolEvent>, emptyText: String): String {
        if (list.isEmpty()) return emptyText
        val sb = StringBuilder()
        val groups = list
            .sortedWith(compareBy<SchoolEvent>({ it.schoolName }, { it.timestamp }))
            .groupBy { it.schoolName }
        groups.forEach { (school, items) ->
            sb.append("المدرسة: ").append(school).append("\n")
            items.forEachIndexed { index, e ->
                sb.append("  ").append(index + 1).append(") ").append(e.title).append("\n")
                sb.append("     الوقت: ").append(e.dateString).append(" - ").append(e.timeString).append("\n")
                sb.append("     التفاصيل: ").append(e.description).append("\n")
            }
            sb.append("\n")
        }
        return sb.toString().trimEnd()
    }

    // ---------- المدارس ----------

    fun saveSchool(id: Long, values: Map<String, String>, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            val school = values.toSchool(id)
            if (id == 0L) {
                db.schoolDao().insert(school)
            } else {
                db.schoolDao().update(school)
            }
            onDone()
        }
    }

    /** حذف المدرسة مع معلميها (الأحداث بتفضل محفوظة في التقارير) */
    fun deleteSchool(school: School) {
        viewModelScope.launch {
            db.teacherDao().deleteBySchool(school.id)
            db.schoolDao().delete(school)
        }
    }

    // ---------- المعلمون ----------

    fun saveTeacher(id: Long, schoolId: Long, values: Map<String, String>, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            val teacher = values.toTeacher(id, schoolId)
            if (id == 0L) {
                db.teacherDao().insert(teacher)
            } else {
                db.teacherDao().update(teacher)
            }
            onDone()
        }
    }

    fun deleteTeacher(teacher: Teacher) {
        viewModelScope.launch { db.teacherDao().delete(teacher) }
    }

    // ---------- الأحداث ----------

    fun saveEvent(event: SchoolEvent) {
        viewModelScope.launch {
            if (event.id == 0L) {
                db.eventDao().insert(event)
            } else {
                db.eventDao().update(event)
            }
        }
    }

    fun deleteEvent(event: SchoolEvent) {
        viewModelScope.launch { db.eventDao().delete(event) }
    }

    // ---------- الاستيراد من Excel / CSV ----------

    fun importSchools(uri: Uri, onDone: (ImportReport) -> Unit) {
        viewModelScope.launch {
            val report = try {
                withContext(Dispatchers.IO) { runSchoolImport(readBytes(uri)) }
            } catch (e: Exception) {
                ImportReport(0, 0, listOf("تعذر قراءة الملف: ${e.message}"))
            }
            onDone(report)
        }
    }

    fun importTeachers(uri: Uri, onDone: (ImportReport) -> Unit) {
        viewModelScope.launch {
            val report = try {
                withContext(Dispatchers.IO) { runTeacherImport(readBytes(uri)) }
            } catch (e: Exception) {
                ImportReport(0, 0, listOf("تعذر قراءة الملف: ${e.message}"))
            }
            onDone(report)
        }
    }

    private fun readBytes(uri: Uri): ByteArray {
        val input = getApplication<Application>().contentResolver.openInputStream(uri) ?: return ByteArray(0)
        return input.use { it.readBytes() }
    }

    private suspend fun runSchoolImport(bytes: ByteArray): ImportReport {
        val (headers, records) = ImportHelper.readRecords(bytes)
        val nameKey = ImportHelper.norm("اسم المدرسة")
        if (!headers.contains(nameKey)) {
            return ImportReport(0, 0, listOf("مش لاقي عمود «اسم المدرسة» في الصف الأول من الملف"))
        }
        var added = 0
        var updated = 0
        val skipped = mutableListOf<String>()
        val known = schools.value.toMutableList()

        records.forEachIndexed { index, rec ->
            val rowNo = index + 2
            val name = rec[nameKey]?.trim().orEmpty()
            if (name.isBlank()) {
                skipped += "صف $rowNo: اسم المدرسة فاضي"
                return@forEachIndexed
            }
            val existing = known.firstOrNull { ImportHelper.norm(it.name) == ImportHelper.norm(name) }
            val merged = (existing?.toValues() ?: mapOf("stage" to SchoolStage.PRIMARY.name)).toMutableMap()
            ImportHelper.valuesFor(rec, SchoolSpec.all).forEach { (k, v) -> merged[k] = v }
            val rawStage = rec[ImportHelper.norm("المرحلة")]
            if (!rawStage.isNullOrBlank()) {
                merged["stage"] = ImportHelper.parseStage(rawStage)
            }

            if (existing == null) {
                val newId = db.schoolDao().insert(merged.toSchool(0L))
                known.add(merged.toSchool(newId))
                added++
            } else {
                val updatedSchool = merged.toSchool(existing.id)
                db.schoolDao().update(updatedSchool)
                known[known.indexOf(existing)] = updatedSchool
                updated++
            }
        }
        return ImportReport(added, updated, skipped)
    }

    private suspend fun runTeacherImport(bytes: ByteArray): ImportReport {
        val (headers, records) = ImportHelper.readRecords(bytes)
        val nameKey = ImportHelper.norm("اسم المعلم")
        val schoolKey = ImportHelper.norm("المدرسة")
        if (!headers.contains(nameKey) || !headers.contains(schoolKey)) {
            return ImportReport(0, 0, listOf("لازم يكون في الصف الأول عمودين: «اسم المعلم» و«المدرسة»"))
        }
        var added = 0
        var updated = 0
        val skipped = mutableListOf<String>()
        val knownSchools = schools.value
        val known = teachers.value.toMutableList()

        records.forEachIndexed { index, rec ->
            val rowNo = index + 2
            val name = rec[nameKey]?.trim().orEmpty()
            val schoolName = rec[schoolKey]?.trim().orEmpty()
            if (name.isBlank()) {
                skipped += "صف $rowNo: اسم المعلم فاضي"
                return@forEachIndexed
            }
            val school = knownSchools.firstOrNull { ImportHelper.norm(it.name) == ImportHelper.norm(schoolName) }
            if (school == null) {
                skipped += "صف $rowNo: المدرسة «$schoolName» مش مسجلة في التطبيق"
                return@forEachIndexed
            }
            val nationalId = rec[ImportHelper.norm("الرقم القومي")]?.trim().orEmpty()
            val existing = known.firstOrNull { t ->
                if (nationalId.isNotBlank()) {
                    t.nationalId == nationalId
                } else {
                    (ImportHelper.norm(t.name) == ImportHelper.norm(name)) && (t.schoolId == school.id)
                }
            }
            val merged = (existing?.toValues() ?: emptyMap()).toMutableMap()
            ImportHelper.valuesFor(rec, TeacherSpec.fields).forEach { (k, v) -> merged[k] = v }

            if (existing == null) {
                val newId = db.teacherDao().insert(merged.toTeacher(0L, school.id))
                known.add(merged.toTeacher(newId, school.id))
                added++
            } else {
                val updatedTeacher = merged.toTeacher(existing.id, school.id)
                db.teacherDao().update(updatedTeacher)
                known[known.indexOf(existing)] = updatedTeacher
                updated++
            }
        }
        return ImportReport(added, updated, skipped)
    }
}
