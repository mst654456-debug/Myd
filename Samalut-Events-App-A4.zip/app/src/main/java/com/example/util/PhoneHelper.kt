package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/** اتصال عادي وواتساب من رقم التليفون */
object PhoneHelper {

    fun call(context: Context, phone: String) {
        val number = phone.filter { it.isDigit() || it == '+' }
        if (number.isEmpty()) { return }
        launchIntent(context, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
    }

    fun whatsapp(context: Context, phone: String) {
        val number = internationalDigits(phone)
        if (number.isEmpty()) { return }
        launchIntent(context, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$number")))
    }

    /** 01012345678 -> 201012345678 */
    fun internationalDigits(phone: String): String {
        var digits = phone.filter { it.isDigit() }
        if (digits.startsWith("00")) digits = digits.substring(2)
        if (digits.startsWith("0")) digits = "20" + digits.substring(1)
        return digits
    }

    private fun launchIntent(context: Context, intent: Intent) {
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "لا يوجد تطبيق مناسب لفتح هذا الإجراء", Toast.LENGTH_SHORT).show()
        }
    }
}
