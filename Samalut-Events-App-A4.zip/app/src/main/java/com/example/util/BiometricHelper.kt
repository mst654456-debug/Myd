package com.example.util

import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * الدخول بالبصمة (أو قفل الجهاز: PIN / النمط على أندرويد 11 فأحدث).
 */
object BiometricHelper {

    private fun authenticators(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) BIOMETRIC_WEAK or DEVICE_CREDENTIAL
        else BIOMETRIC_WEAK

    /** هل الجهاز يدعم البصمة (أو قفل الشاشة) ومفعّل عليه؟ */
    fun isAvailable(context: Context): Boolean =
        BiometricManager.from(context).canAuthenticate(authenticators()) == BiometricManager.BIOMETRIC_SUCCESS

    /** رسالة توضح سبب عدم توفر البصمة */
    fun unavailableReason(context: Context): String =
        when (BiometricManager.from(context).canAuthenticate(authenticators())) {
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "لا توجد بصمة مسجلة على الجهاز. أضف بصمتك من إعدادات الجهاز ثم أعد المحاولة."
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> "هذا الجهاز لا يدعم البصمة."
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> "مستشعر البصمة غير متاح حالياً."
            else -> "تعذر استخدام البصمة على هذا الجهاز."
        }

    fun findActivity(context: Context): FragmentActivity? {
        var ctx: Context? = context
        while (ctx is ContextWrapper) {
            if (ctx is FragmentActivity) return ctx
            ctx = ctx.baseContext
        }
        return null
    }

    fun authenticate(
        activity: FragmentActivity,
        title: String = "تسجيل الدخول",
        subtitle: String = "ضع إصبعك على مستشعر البصمة للدخول",
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    // 10 = المستخدم ألغى، 13 = ضغط إلغاء: لا نعرض خطأ مزعجاً
                    if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                        errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                        errorCode != BiometricPrompt.ERROR_CANCELED
                    ) {
                        onError(errString.toString())
                    }
                }
            }
        )

        val builder = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setAllowedAuthenticators(authenticators())
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            // لا يمكن الجمع مع DEVICE_CREDENTIAL على الإصدارات الأقدم
            builder.setNegativeButtonText("إلغاء")
        }
        prompt.authenticate(builder.build())
    }
}
