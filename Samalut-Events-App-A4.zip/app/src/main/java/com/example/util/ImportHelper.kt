package com.example.util

import android.util.Xml
import com.example.data.model.FieldKind
import com.example.data.model.FormField
import com.example.data.model.SchoolStage
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

data class ImportReport(val added: Int, val updated: Int, val skipped: List<String>)

/** قراءة ملفات Excel (xlsx) وCSV بدون مكتبات خارجية */
object ImportHelper {

    /** توحيد اسم العمود عشان المقارنة تتجاهل المسافات والهمزات وعلامات الترقيم */
    fun norm(text: String): String = text.trim()
        .replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
        .replace("ة", "ه").replace("ى", "ي")
        .replace("ئ", "ء").replace("ؤ", "ء")
        .replace(Regex("[\\s*/:،.\\-()_]+"), "")
        .lowercase()

    fun parseStage(raw: String): String {
        val value = norm(raw)
        return SchoolStage.values().firstOrNull { norm(it.displayNameAr) == value }?.name
            ?: SchoolStage.values().firstOrNull { value.contains(norm(it.displayNameAr)) }?.name
            ?: SchoolStage.PRIMARY.name
    }

    /** يرجع أسماء الأعمدة (موحدة) + الصفوف كـ map لكل صف */
    fun readRecords(bytes: ByteArray): Pair<List<String>, List<Map<String, String>>> {
        if (bytes.isEmpty()) return emptyList<String>() to emptyList<Map<String, String>>()
        val table = if (isZip(bytes)) readXlsx(bytes)
        else parseCsv(String(bytes, Charsets.UTF_8).removePrefix("\uFEFF"))
        if (table.isEmpty()) return emptyList<String>() to emptyList<Map<String, String>>()
        val headers = table.first().map { norm(it) }
        val records = table.drop(1)
            .filter { row -> row.any { it.isNotBlank() } }
            .map { row ->
                headers.withIndex().associate { (index, header) ->
                    header to row.getOrElse(index) { "" }
                }
            }
        return headers to records
    }

    /** يحول صف Excel لقيم الفورم حسب تعريف الحقول، ويصلح أرقام التليفون اللي فقدت الصفر */
    fun valuesFor(record: Map<String, String>, fields: List<FormField>): Map<String, String> {
        val out = mutableMapOf<String, String>()
        fields.forEach { field ->
            val raw = record[norm(field.label)]?.trim() ?: return@forEach
            if (raw.isEmpty()) return@forEach
            out[field.key] = if (field.kind == FieldKind.PHONE) fixPhone(raw) else raw
        }
        return out
    }

    private fun fixPhone(raw: String): String {
        val digits = raw.filter { it.isDigit() }
        return if (digits.length == 10 && digits.startsWith("1")) "0$digits" else raw
    }

    private fun isZip(bytes: ByteArray): Boolean =
        bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte()

    private fun readXlsx(bytes: ByteArray): List<List<String>> {
        var shared: List<String> = emptyList()
        var sheet: ByteArray? = null
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val name = entry.name
                if (name == "xl/sharedStrings.xml") {
                    shared = parseSharedStrings(zip.readBytes())
                } else if (sheet == null && name.startsWith("xl/worksheets/sheet") && name.endsWith(".xml")) {
                    sheet = zip.readBytes()
                }
                entry = zip.nextEntry
            }
        }
        val sheetBytes = sheet ?: return emptyList()
        return parseSheet(sheetBytes, shared)
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val out = mutableListOf<String>()
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        var current: StringBuilder? = null
        var inText = false
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                if (parser.name == "si") current = StringBuilder()
                if (parser.name == "t") inText = true
            } else if (event == XmlPullParser.TEXT) {
                if (inText) current?.append(parser.text)
            } else if (event == XmlPullParser.END_TAG) {
                if (parser.name == "t") inText = false
                if (parser.name == "si") {
                    out.add(current?.toString().orEmpty())
                    current = null
                }
            }
            event = parser.next()
        }
        return out
    }

    private fun parseSheet(bytes: ByteArray, shared: List<String>): List<List<String>> {
        val rows = mutableListOf<MutableMap<Int, String>>()
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        var row: MutableMap<Int, String>? = null
        var ref = ""
        var type = ""
        var capture = false
        val text = StringBuilder()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (parser.name) {
                    "row" -> row = mutableMapOf()
                    "c" -> {
                        ref = parser.getAttributeValue(null, "r") ?: ""
                        type = parser.getAttributeValue(null, "t") ?: ""
                        text.setLength(0)
                    }
                    "v", "t" -> capture = true
                }
            } else if (event == XmlPullParser.TEXT) {
                if (capture) text.append(parser.text)
            } else if (event == XmlPullParser.END_TAG) {
                when (parser.name) {
                    "v", "t" -> capture = false
                    "c" -> {
                        val raw = text.toString().trim()
                        val value = if (type == "s") shared.getOrNull(raw.toIntOrNull() ?: -1) ?: "" else raw
                        row?.put(colIndex(ref).coerceAtLeast(0), value)
                    }
                    "row" -> row?.let { rows.add(it) }
                }
            }
            event = parser.next()
        }
        if (rows.isEmpty()) return emptyList()
        val lastColumn = rows.maxOf { r -> r.keys.maxOrNull() ?: 0 }
        return rows.map { r -> (0..lastColumn).map { c -> r[c]?.trim().orEmpty() } }
    }

    /** "C5" -> 2 (العمود الأول = 0) */
    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) {
            if (!ch.isLetter()) break
            n = n * 26 + (ch.uppercaseChar() - 'A' + 1)
        }
        return n - 1
    }

    private fun parseCsv(text: String): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        val field = StringBuilder()
        var quoted = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (quoted && c == '"' && i + 1 < text.length && text[i + 1] == '"') {
                field.append('"')
                i++
            } else if (c == '"') {
                quoted = !quoted
            } else if (!quoted && c == ',') {
                row.add(field.toString().trim())
                field.setLength(0)
            } else if (!quoted && (c == '\n' || c == '\r')) {
                if (c == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                row.add(field.toString().trim())
                field.setLength(0)
                rows.add(row)
                row = mutableListOf()
            } else {
                field.append(c)
            }
            i++
        }
        if (field.isNotEmpty() || row.isNotEmpty()) {
            row.add(field.toString().trim())
            rows.add(row)
        }
        return rows.filter { r -> r.any { it.isNotBlank() } }
    }
}
