package com.example.data.model

enum class FieldKind { TEXT, MULTILINE, NUMBER, DECIMAL, PHONE }

/** حقل في الفورم. الـ label هو نفسه اسم العمود في ملف Excel */
data class FormField(
    val key: String,
    val label: String,
    val kind: FieldKind = FieldKind.TEXT,
    val required: Boolean = false
)

object SchoolSpec {
    val basic = listOf(
        FormField("name", "اسم المدرسة", required = true),
        FormField("code", "كود المدرسة"),
        FormField("serialNumber", "الرقم المسلسل"),
        FormField("address", "عنوان المدرسة")
    )

    val leadership = listOf(
        FormField("principalName", "اسم مدير المدرسة"),
        FormField("principalPhone", "تليفون مدير المدرسة", FieldKind.PHONE),
        FormField("vicePrincipalName", "اسم وكيل المدرسة"),
        FormField("vicePrincipalPhone", "تليفون وكيل المدرسة", FieldKind.PHONE),
        FormField("securityOfficerName", "اسم مسئول الأمن"),
        FormField("securityOfficerPhone", "تليفون مسئول الأمن", FieldKind.PHONE),
        FormField("crisisOfficerName", "اسم مسئول الأزمات"),
        FormField("crisisOfficerPhone", "تليفون مسئول الأزمات", FieldKind.PHONE),
        FormField("safetyOfficerName", "اسم مسئول السلامة والصحة المهنية"),
        FormField("safetyOfficerPhone", "تليفون مسئول السلامة", FieldKind.PHONE)
    )

    val stats = listOf(
        FormField("teachersCount", "عدد المعلمين", FieldKind.NUMBER),
        FormField("specialistsCount", "عدد الأخصائيين", FieldKind.NUMBER),
        FormField("administrativeCount", "عدد الإداريين", FieldKind.NUMBER),
        FormField("workersCount", "عدد العمال", FieldKind.NUMBER),
        FormField("classroomsCount", "عدد الفصول", FieldKind.NUMBER),
        FormField("capacity", "الطاقة الاستيعابية", FieldKind.NUMBER),
        FormField("studentsTotal", "إجمالي الطلاب", FieldKind.NUMBER),
        FormField("boysCount", "عدد البنين", FieldKind.NUMBER),
        FormField("girlsCount", "عدد البنات", FieldKind.NUMBER),
        FormField("toiletsCount", "عدد دورات المياه", FieldKind.NUMBER),
        FormField("buildingsCount", "عدد المباني", FieldKind.NUMBER),
        FormField("totalArea", "المساحة الإجمالية")
    )

    /** لكل بند: الإجمالي + الصالح للعمل (غير الصالح = الفرق) */
    val safety = listOf(
        FormField("extinguishers", "عدد الطفايات", FieldKind.NUMBER),
        FormField("extinguishersOk", "الطفايات الصالحة للعمل", FieldKind.NUMBER),
        FormField("hoses", "عدد الخراطيم", FieldKind.NUMBER),
        FormField("hosesOk", "الخراطيم الصالحة للعمل", FieldKind.NUMBER),
        FormField("waterPumps", "عدد مواتير المياه", FieldKind.NUMBER),
        FormField("waterPumpsOk", "المواتير الصالحة للعمل", FieldKind.NUMBER),
        FormField("tanks", "عدد الخزانات", FieldKind.NUMBER),
        FormField("tanksOk", "الخزانات الصالحة للعمل", FieldKind.NUMBER),
        FormField("sandBuckets", "عدد جرادل الرمل", FieldKind.NUMBER),
        FormField("sandBucketsOk", "جرادل الرمل الصالحة", FieldKind.NUMBER),
        FormField("cameras", "عدد الكاميرات", FieldKind.NUMBER),
        FormField("camerasOk", "الكاميرات الصالحة للعمل", FieldKind.NUMBER),
        FormField("gates", "عدد بوابات المدرسة والمخارج", FieldKind.NUMBER),
        FormField("gatesOk", "البوابات الصالحة للعمل", FieldKind.NUMBER)
    )

    val location = listOf(
        FormField("latitude", "إحداثيات خط العرض", FieldKind.DECIMAL),
        FormField("longitude", "إحداثيات خط الطول", FieldKind.DECIMAL)
    )

    val problems = listOf(
        FormField("problems", "المشكلات داخل المدرسة", FieldKind.MULTILINE)
    )

    val all: List<FormField> = basic + leadership + stats + safety + location + problems
}

object TeacherSpec {
    val fields = listOf(
        FormField("name", "اسم المعلم", required = true),
        FormField("code", "كود المعلم"),
        FormField("nationalId", "الرقم القومي", FieldKind.NUMBER),
        FormField("phone", "تليفون المعلم", FieldKind.PHONE),
        FormField("address", "عنوان المعلم"),
        FormField("notes", "ملاحظات", FieldKind.MULTILINE)
    )
}

private fun Int.asField(): String = if (this == 0) "" else this.toString()

/** تحويل المدرسة لقيم الفورم (key -> نص) */
fun School.toValues(): Map<String, String> = mapOf(
    "name" to name,
    "code" to code,
    "serialNumber" to serialNumber,
    "stage" to stage,
    "address" to address,
    "principalName" to principalName,
    "principalPhone" to principalPhone,
    "vicePrincipalName" to vicePrincipalName,
    "vicePrincipalPhone" to vicePrincipalPhone,
    "securityOfficerName" to securityOfficerName,
    "securityOfficerPhone" to securityOfficerPhone,
    "crisisOfficerName" to crisisOfficerName,
    "crisisOfficerPhone" to crisisOfficerPhone,
    "safetyOfficerName" to safetyOfficerName,
    "safetyOfficerPhone" to safetyOfficerPhone,
    "teachersCount" to teachersCount.asField(),
    "specialistsCount" to specialistsCount.asField(),
    "administrativeCount" to administrativeCount.asField(),
    "workersCount" to workersCount.asField(),
    "classroomsCount" to classroomsCount.asField(),
    "capacity" to capacity.asField(),
    "studentsTotal" to studentsTotal.asField(),
    "boysCount" to boysCount.asField(),
    "girlsCount" to girlsCount.asField(),
    "toiletsCount" to toiletsCount.asField(),
    "buildingsCount" to buildingsCount.asField(),
    "totalArea" to totalArea,
    "extinguishers" to extinguishers.asField(),
    "extinguishersOk" to extinguishersOk.asField(),
    "hoses" to hoses.asField(),
    "hosesOk" to hosesOk.asField(),
    "waterPumps" to waterPumps.asField(),
    "waterPumpsOk" to waterPumpsOk.asField(),
    "tanks" to tanks.asField(),
    "tanksOk" to tanksOk.asField(),
    "sandBuckets" to sandBuckets.asField(),
    "sandBucketsOk" to sandBucketsOk.asField(),
    "cameras" to cameras.asField(),
    "camerasOk" to camerasOk.asField(),
    "gates" to gates.asField(),
    "gatesOk" to gatesOk.asField(),
    "latitude" to latitude,
    "longitude" to longitude,
    "problems" to problems
)

/** تحويل قيم الفورم لمدرسة */
fun Map<String, String>.toSchool(id: Long): School {
    fun s(key: String): String = this[key]?.trim().orEmpty()
    fun n(key: String): Int = s(key).toDoubleOrNull()?.toInt() ?: 0
    return School(
        id = id,
        name = s("name"),
        code = s("code"),
        serialNumber = s("serialNumber"),
        stage = s("stage").ifBlank { SchoolStage.PRIMARY.name },
        address = s("address"),
        principalName = s("principalName"),
        principalPhone = s("principalPhone"),
        vicePrincipalName = s("vicePrincipalName"),
        vicePrincipalPhone = s("vicePrincipalPhone"),
        securityOfficerName = s("securityOfficerName"),
        securityOfficerPhone = s("securityOfficerPhone"),
        crisisOfficerName = s("crisisOfficerName"),
        crisisOfficerPhone = s("crisisOfficerPhone"),
        safetyOfficerName = s("safetyOfficerName"),
        safetyOfficerPhone = s("safetyOfficerPhone"),
        teachersCount = n("teachersCount"),
        specialistsCount = n("specialistsCount"),
        administrativeCount = n("administrativeCount"),
        workersCount = n("workersCount"),
        classroomsCount = n("classroomsCount"),
        capacity = n("capacity"),
        studentsTotal = n("studentsTotal"),
        boysCount = n("boysCount"),
        girlsCount = n("girlsCount"),
        toiletsCount = n("toiletsCount"),
        buildingsCount = n("buildingsCount"),
        totalArea = s("totalArea"),
        extinguishers = n("extinguishers"),
        extinguishersOk = n("extinguishersOk"),
        hoses = n("hoses"),
        hosesOk = n("hosesOk"),
        waterPumps = n("waterPumps"),
        waterPumpsOk = n("waterPumpsOk"),
        tanks = n("tanks"),
        tanksOk = n("tanksOk"),
        sandBuckets = n("sandBuckets"),
        sandBucketsOk = n("sandBucketsOk"),
        cameras = n("cameras"),
        camerasOk = n("camerasOk"),
        gates = n("gates"),
        gatesOk = n("gatesOk"),
        latitude = s("latitude"),
        longitude = s("longitude"),
        problems = s("problems")
    )
}

fun Teacher.toValues(): Map<String, String> = mapOf(
    "name" to name,
    "code" to code,
    "nationalId" to nationalId,
    "phone" to phone,
    "address" to address,
    "notes" to notes
)

fun Map<String, String>.toTeacher(id: Long, schoolId: Long): Teacher {
    fun s(key: String): String = this[key]?.trim().orEmpty()
    return Teacher(
        id = id,
        schoolId = schoolId,
        name = s("name"),
        code = s("code"),
        nationalId = s("nationalId"),
        phone = s("phone"),
        address = s("address"),
        notes = s("notes")
    )
}
